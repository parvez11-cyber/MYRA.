# MYRA update notes (26 Nov 2026)

Build: AGP 9.5.0 (built-in Kotlin) | Gradle 9.6.0 | Kotlin/Compose compiler plugin 2.4.21 | compileSdk 36 / targetSdk 36 | minSdk 26
Libraries: Compose BOM 2026.11.01 (Material3 1.5.0), activity 1.13.0, lifecycle 2.11.1, core-ktx 1.19.1, appcompat 1.8.0,
fragment 1.9.1, material 1.14.0, webkit 1.18.0, coroutines 1.11.0, OkHttp 5.5.1, Retrofit 3.0.0, ML Kit text-recognition 16.0.1.
AI models: Live voice = gemini-3.8-live (old 2.5 native-audio preview was shut down 17 Nov 2026), chat/vision = gemini-3.8-flash.
Needs JDK 17+ and Android Studio with Android 16 (API 36) SDK installed.

## MYRA UI / offline event update
- Kept the Maya Compose UI and three-step setup flow as the primary launcher experience.
- Added an always-on floating-orb microphone state indicator: gray while idle and cyan while the microphone is enabled. The indicator follows the app's `MYRA_MIC_STATE` event and can remain visible over other apps when overlay permission is granted.
- Added local Android TextToSpeech announcements for charger connected/disconnected and battery low/okay events. These announcements do not call Gemini and work without an internet connection. They can be disabled with the `offline_power_voice` preference (defaults to enabled).

## Verification
- Source and manifest changes were inspected.
- A debug APK build could not be completed in this environment because the Gradle wrapper distribution could not be downloaded (network DNS unavailable). Build on a machine with Android SDK / Gradle access before installing.
- Android OS restrictions still apply: background microphone capture, overlay display, notification access, and battery-optimization exemptions require user-granted permissions and may vary by device manufacturer.
