package com.myra.assistant.ui.maya

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.location.LocationManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CenterFocusStrong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.services.ForegroundVoiceService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.utils.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

private const val VERSION = "v5.2.67"
data class Msg(val fromUser: Boolean, val text: String)
enum class Tab { Home, Scan, Yaadein, Chat }

private fun Modifier.soft(r: Int = 24, e: Int = 8) =
    this.shadow(e.dp, RoundedCornerShape(r.dp), ambientColor = Color.White, spotColor = Color(0x663B5A9A))
        .clip(RoundedCornerShape(r.dp)).background(Brush.verticalGradient(listOf(Color(0xFFF8FAFF), MC.Card)))

@Composable
private fun RoundBtn(icon: ImageVector, dot: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.size(54.dp).soft(27, 8).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = MC.Navy)
        if (dot) Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(11.dp).clip(CircleShape).background(MC.Dot))
    }
}

@Composable
fun MayaApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    var tab by remember { mutableStateOf(Tab.Home) }
    val msgs = remember { mutableStateListOf<Msg>() }
    var busy by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Maya") }
    val history = remember {
        mutableStateListOf<String>().apply {
            runCatching { JSONArray(prefs.getString("chat_history", "[]")).let { a -> for (i in 0 until a.length()) add(a.getString(i)) } }
        }
    }
    var showHistory by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }

    fun key() = prefs.getString(Constants.KEY_API_KEY, "").orEmpty()
    fun send(text: String, imageB64: String? = null, mime: String = "image/jpeg") {
        if (text.isBlank() || busy) return
        val past = msgs.map { it.fromUser to it.text }
        msgs.add(Msg(true, text)); busy = true
        scope.launch {
            val sys = "You are Maya, a warm Hinglish-speaking AI assistant." +
                (if (mode != "Maya") " Current area: $mode." else "") +
                prefs.getString("maya_rules", "").orEmpty().let { if (it.isNotBlank()) "\nUser's rules you must follow:\n$it" else "" } +
                PersistentMemory.contextForAI().let { if (it.isNotBlank()) "\nWhat you know about the user:\n$it" else "" }
            val r = if (key().isEmpty()) "Pehle Gemini key daalo (Settings me)." else GeminiChat.ask(key(), past, text, imageB64, mime, sys)
            msgs.add(Msg(false, r)); busy = false
        }
    }
    fun readAttachment(uri: Uri): Triple<String, String, String?>? = try {
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else "file"
        } ?: "file"
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
        if (bytes.isEmpty() || bytes.size > 15_000_000) null
        else if (mime.startsWith("image/") || mime == "application/pdf")
            Triple(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP))
        else Triple(name, "text/plain", String(bytes, Charsets.UTF_8).take(60_000))
    } catch (_: Exception) { null }
    fun sendAttachment(uri: Uri, ask: String) {
        val a = readAttachment(uri)
        if (a == null) { msgs.add(Msg(false, "File padh nahi payi (15MB tak, image / PDF / .md / text).")); return }
        val (name, mime, data) = a
        if (mime == "text/plain") send("$ask\n\n[$name]\n$data") else send("$ask ($name)", data, mime)
    }
    fun startVoice() {
        if (key().isEmpty()) { msgs.add(Msg(false, "Pehle Gemini key daalo.")); tab = Tab.Chat; return }
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, ForegroundVoiceService::class.java)) } catch (_: Exception) {}
    }
    fun clearChat() {
        if (msgs.isNotEmpty()) {
            if (prefs.getBoolean("auto_memory", true) && key().isNotEmpty()) {
                val convo = msgs.joinToString("\n") { (if (it.fromUser) "User: " else "Maya: ") + it.text }
                scope.launch { GeminiChat.extractFacts(key(), convo).forEach { PersistentMemory.add(it) } }
            }
            history.add(0, msgs.joinToString("\n") { (if (it.fromUser) "Me: " else "Maya: ") + it.text })
            prefs.edit().putString("chat_history", JSONArray(history.toList()).toString()).apply()
            msgs.clear()
        }
    }
    fun go(t: Tab, m: String = "Maya") { mode = m; tab = t; scope.launch { drawer.close() } }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            DrawerContent(
                onHome = { go(Tab.Home) },
                onArea = { go(Tab.Chat, it) },
                onSettings = { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) },
                onAccessibility = { Perms.open(ctx, 3) },
                onPhotos = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                onBrowser = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                onDialog = { scope.launch { drawer.close() }; dialog = it }
            )
        }
    ) {
        Box(Modifier.fillMaxSize().background(MC.LightBg)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundBtn(Icons.Filled.Menu) { scope.launch { drawer.open() } }
                    Spacer(Modifier.width(16.dp))
                    Text(when (tab) { Tab.Home -> "Maya"; Tab.Scan -> "Scan"; Tab.Yaadein -> "Yaadein"; Tab.Chat -> "Chat" },
                        color = MC.Navy, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    RoundBtn(Icons.Filled.NotificationsNone, dot = true) { dialog = "Notifications" }
                }
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        Tab.Home -> HomeTab(onSend = { go(Tab.Chat); send(it) }, onAttach = { go(Tab.Chat); sendAttachment(it, "Is file ke baare me batao.") }, onActivate = { dialog = "Upgrade" })
                        Tab.Scan -> ScanTab { b64 -> go(Tab.Chat, "Scan"); send("Is photo me kya hai? Batao.", b64) }
                        Tab.Yaadein -> YaadeinTab()
                        Tab.Chat -> ChatTab(mode, msgs, busy, maxOf(1, history.size), onSend = { send(it) }, onAttach = { sendAttachment(it, "Is file ke baare me batao.") },
                            onClear = { clearChat() }, onHistory = { showHistory = true })
                    }
                }
                BottomBar(tab, onTab = { go(it) }, onMic = { startVoice() })
            }
        }
    }
    dialog?.let { MayaDialog(it, prefs) { dialog = null } }
    if (showHistory) AlertDialog(
        onDismissRequest = { showHistory = false }, confirmButton = { TextButton({ showHistory = false }) { Text("Close") } },
        title = { Text("History") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            if (history.isEmpty()) Text("Abhi koi purani chat nahi hai.")
            history.forEachIndexed { i, h -> Text("${i + 1}. " + h.take(160), modifier = Modifier.padding(vertical = 6.dp)) }
        } })
}

@Composable
private fun BottomBar(tab: Tab, onTab: (Tab) -> Unit, onMic: () -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().height(80.dp).soft(40, 10).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            @Composable fun item(t: Tab, icon: ImageVector, label: String) {
                val sel = tab == t
                Column(
                    Modifier.weight(1f).padding(vertical = 6.dp).clip(RoundedCornerShape(22.dp))
                        .then(if (sel) Modifier.background(Brush.verticalGradient(listOf(Color(0xFF5CB0FF), MC.BlueDeep))) else Modifier)
                        .clickable { onTab(t) }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(icon, null, tint = if (sel) Color.White else MC.Navy)
                    Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else MC.Navy)
                }
            }
            item(Tab.Home, Icons.Filled.Home, "Home")
            item(Tab.Scan, Icons.Outlined.CenterFocusStrong, "Scan")
            Spacer(Modifier.weight(1f))
            item(Tab.Yaadein, Icons.Filled.Psychology, "Yaadein")
            item(Tab.Chat, Icons.Filled.Forum, "Chat")
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-18).dp).size(98.dp)
                .shadow(14.dp, CircleShape, spotColor = Color(0xAA1E6FD9)).clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF6CB8FF), MC.BlueDeep))).clickable(onClick = onMic),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(64.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Mic, null, tint = MC.BlueDeep, modifier = Modifier.size(32.dp))
            }
        }
    }
}

@Composable
private fun InputBar(hint: String, onSend: (String) -> Unit, onAttach: (Uri) -> Unit = {}, modifier: Modifier = Modifier) {
    var t by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> if (u != null) onAttach(u) }
    Row(modifier.fillMaxWidth().height(58.dp).soft(29, 4).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.AttachFile, null, tint = MC.Hint, modifier = Modifier.clickable { picker.launch("*/*") })
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (t.isEmpty()) Text(hint, color = MC.Hint, fontSize = 17.sp)
            BasicTextField(t, { t = it }, singleLine = true, textStyle = TextStyle(color = MC.Navy, fontSize = 17.sp),
                cursorBrush = SolidColor(MC.Navy), modifier = Modifier.fillMaxWidth())
        }
        Box(Modifier.size(44.dp).soft(22, 4).clickable { if (t.isNotBlank()) { onSend(t.trim()); t = "" } }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Send, null, tint = MC.Navy, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun MayaCharacter(modifier: Modifier) {
    val ctx = LocalContext.current
    val id = remember { ctx.resources.getIdentifier("maya_character", "drawable", ctx.packageName) }
    if (id != 0) Image(painterResource(id), null, modifier, contentScale = ContentScale.Fit)
    else Canvas(modifier) { // placeholder until maya_character.png is added to res/drawable
        val w = size.width; val h = size.height
        drawCircle(Color(0xFF2B2030), w * 0.13f, Offset(w / 2, h * 0.12f))
        drawCircle(Color(0xFFF1D3C0), w * 0.085f, Offset(w / 2, h * 0.13f))
        val p = Path().apply {
            moveTo(w * 0.36f, h * 0.22f); lineTo(w * 0.64f, h * 0.22f); lineTo(w * 0.78f, h * 0.62f)
            lineTo(w * 0.22f, h * 0.62f); close()
        }
        drawPath(p, Color(0xFFD4302F))
        drawRect(Color(0xFFF1D3C0), Offset(w * 0.40f, h * 0.62f), androidx.compose.ui.geometry.Size(w * 0.07f, h * 0.30f))
        drawRect(Color(0xFFF1D3C0), Offset(w * 0.53f, h * 0.62f), androidx.compose.ui.geometry.Size(w * 0.07f, h * 0.30f))
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun HomeTab(onSend: (String) -> Unit, onAttach: (Uri) -> Unit, onActivate: () -> Unit) {
    val ctx = LocalContext.current
    val date = remember { Date() }
    var temp by remember { mutableStateOf("--") }
    var cond by remember { mutableStateOf("—") }
    var hum by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time } ?: return@withContext
                val url = java.net.URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,relative_humidity_2m,weather_code")
                val c = JSONObject(url.readText()).getJSONObject("current")
                temp = "${c.getDouble("temperature_2m").toInt()}°"; hum = "${c.getInt("relative_humidity_2m")}%"
                cond = when (c.getInt("weather_code")) { 0 -> "Clear"; 1, 2, 3 -> "Cloudy"; in 45..48 -> "Fog"; in 51..67 -> "Rain"; in 71..77 -> "Snow"; in 80..99 -> "Storm"; else -> "—" }
            } catch (_: Exception) {}
        }
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Color(0x223B8EEA)
            val w = size.width; val h = size.height
            val pts = listOf(Offset(0f, h * 0.55f), Offset(w * 0.25f, h * 0.66f), Offset(w * 0.45f, h * 0.60f), Offset(w * 0.8f, h * 0.50f), Offset(w, h * 0.62f))
            for (i in 0 until pts.size - 1) drawLine(c, pts[i], pts[i + 1], 3f)
            drawCircle(c, w * 0.42f, Offset(w * 0.55f, h * 0.45f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
        }
        MayaCharacter(Modifier.align(Alignment.TopCenter).padding(top = 90.dp, bottom = 190.dp).fillMaxWidth().fillMaxHeight(0.78f))
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFFC6D8F2)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lock, null, tint = MC.Blue)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Free mode • aaj 10:00 min baaki", color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("Saare tools aur unlimited baat ke liye license activate karo", color = MC.Sub, fontSize = 13.sp)
                }
                Text("Activate karo", color = MC.Blue, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onActivate))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                    Text(if (h in 5..11) "Subah ho gayi," else if (h in 12..17) "Dopahar hai," else if (h in 18..22) "Shaam ho gayi," else "Abhi tak jaag rahe ho,",
                        color = MC.Sub, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Text("dost", color = MC.Navy, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                }
                Row(Modifier.soft(20, 6).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Bolt, null, tint = Color(0xFFF59E0B))
                    Spacer(Modifier.width(8.dp))
                    Column { Text("1", color = MC.Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Energy", color = MC.Sub, fontSize = 14.sp) }
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("Gaane" to Icons.Filled.MusicNote, "Padhai" to Icons.Filled.MenuBook, "Journal" to Icons.Filled.Edit).forEach { (t, i) ->
                    Row(Modifier.weight(1f).height(54.dp).soft(20, 6).clickable { onSend(when (t) { "Gaane" -> "Mere liye ek accha gaana suggest karo"; "Padhai" -> "Padhai me meri madad karo"; else -> "Aaj ka journal likhne me madad karo" }) },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(i, null, tint = MC.BlueDeep, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                        Text(t, color = MC.Navy, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoCard(Modifier.weight(1f), Icons.Filled.WbSunny, "Mausam", temp, cond, if (hum.isEmpty()) "" else "💧 $hum")
                InfoCard(Modifier.weight(1f), Icons.Filled.CalendarToday, "Aaj", SimpleDateFormat("d", Locale.ENGLISH).format(date), SimpleDateFormat("EEE, MMM", Locale.ENGLISH).format(date), "")
                InfoCard(Modifier.weight(1f), Icons.Filled.Favorite, "Mood", "Pyaar bhari", "Sab badhiya", "", small = true)
            }
            Spacer(Modifier.height(12.dp))
            InputBar("Maya se kuch bhi poochho...", onSend, onAttach)
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun InfoCard(m: Modifier, icon: ImageVector, label: String, big: String, sub: String, extra: String, small: Boolean = false) {
    Box(m.height(160.dp).soft(26, 8)) {
    if (label == "Mood") Icon(Icons.Filled.Favorite, null, tint = Color(0x44E0457B), modifier = Modifier.align(Alignment.Center).size(64.dp))
    Column(Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MC.Navy, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
            Text(label, color = MC.Sub, fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))
        Text(big, color = MC.Navy, fontSize = if (small) 20.sp else 28.sp, fontWeight = FontWeight.ExtraBold)
        Text(sub, color = MC.Sub, fontSize = 14.sp)
        if (extra.isNotEmpty()) { Spacer(Modifier.height(10.dp)); Text(extra, color = MC.Hint, fontSize = 14.sp) }
    }
    }
}

@Composable
private fun ChatTab(mode: String, msgs: List<Msg>, busy: Boolean, hist: Int, onSend: (String) -> Unit, onAttach: (Uri) -> Unit, onClear: () -> Unit, onHistory: () -> Unit) {
    val state = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.animateScrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(mode, color = MC.Sub, fontWeight = FontWeight.Medium, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Row(Modifier.clickable(onClick = onClear).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Delete, null, tint = MC.Sub, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Clear", color = MC.Sub, fontSize = 16.sp)
            }
            Row(Modifier.clickable(onClick = onHistory).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.History, null, tint = MC.Sub, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("History ($hist)", color = MC.Sub, fontSize = 16.sp)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) Column(Modifier.align(Alignment.TopCenter).padding(top = 50.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Forum, null, tint = MC.Hint, modifier = Modifier.size(40.dp)); Spacer(Modifier.height(10.dp))
                Text("Maya se kuchh bhi poochho —", color = MC.Sub, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text("text likho, ya image / PDF / .md file bhejo.", color = MC.Sub, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            } else LazyColumn(state = state, verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
                items(msgs) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(m.text, color = if (m.fromUser) Color.White else MC.Navy, fontSize = 16.sp,
                            modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(20.dp))
                                .background(if (m.fromUser) MC.BlueDeep else Color.White).padding(14.dp))
                    }
                }
                if (busy) item { Text("Maya soch rahi hai…", color = MC.Hint, modifier = Modifier.padding(8.dp)) }
            }
        }
        InputBar("Maya se kuchh bhi poochho...", onSend, onAttach)
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun ScanTab(onResult: (String) -> Unit) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) { val o = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 85, o); onResult(Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)) }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Outlined.CenterFocusStrong, null, tint = MC.BlueDeep, modifier = Modifier.size(96.dp))
        Spacer(Modifier.height(16.dp))
        Text("Kuch bhi dikhao, Maya batayegi", color = MC.Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.soft(30, 8).clickable { launcher.launch(null) }.padding(horizontal = 36.dp, vertical = 16.dp)) {
            Text("Photo kheencho", color = MC.BlueDeep, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun YaadeinTab() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var auto by remember { mutableStateOf(prefs.getBoolean("auto_memory", true)) }
    var mem by remember { mutableStateOf(PersistentMemory.all()) }
    var busy by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    fun toast(t: String) = android.widget.Toast.makeText(ctx, t, android.widget.Toast.LENGTH_SHORT).show()
    val resumePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u == null) return@rememberLauncherForActivityResult
        val key = prefs.getString(Constants.KEY_API_KEY, "").orEmpty()
        if (key.isEmpty()) { toast("Pehle Gemini key daalo"); return@rememberLauncherForActivityResult }
        busy = true
        scope.launch {
            val facts = withContext(Dispatchers.IO) {
                try {
                    val mime = ctx.contentResolver.getType(u) ?: ""
                    val bytes = ctx.contentResolver.openInputStream(u)?.use { it.readBytes() } ?: ByteArray(0)
                    if (mime == "application/pdf" || mime.startsWith("image/"))
                        GeminiChat.extractFacts(key, "Document attached.", Base64.encodeToString(bytes, Base64.NO_WRAP), mime)
                    else GeminiChat.extractFacts(key, String(bytes, Charsets.UTF_8).take(60_000))
                } catch (_: Exception) { emptyList() }
            }
            facts.forEach { PersistentMemory.add(it) }
            mem = PersistentMemory.all(); busy = false
            toast(if (facts.isEmpty()) "Kuch nahi mila" else "${facts.size} baatein yaad kar li")
        }
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u == null) return@rememberLauncherForActivityResult
        try {
            val lines = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readLines().orEmpty()
                .map { it.trim().trimStart('•', '-', ' ') }.filter { it.length > 3 }
            lines.forEach { PersistentMemory.add(it) }
            mem = PersistentMemory.all(); toast("${lines.size} yaadein wapas aayi")
        } catch (_: Exception) { toast("Restore nahi hua") }
    }
    val tasks = listOf(
        Triple("gemini se poochho", "8 steps · sawaal · built-in", "com.google.android.apps.bard"),
        Triple("chatgpt se poochho", "8 steps · sawaal · built-in", "com.openai.chatgpt"),
        Triple("gemini video", "16 steps · video prompt · built-in", "com.google.android.apps.bard"),
        Triple("gemini image", "17 steps · image prompt · built-in", "com.google.android.apps.bard"),
        Triple("chatgpt image", "14 steps · image prompt · built-in", "com.openai.chatgpt"))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
        Text("Mere baare me", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(if (mem.isEmpty()) "Abhi khaali hai. Apni details batao ya resume bhejo — main yaad rakhungi." else mem.joinToString("\n• ", prefix = "• "),
            color = MC.Sub, fontSize = 17.sp, lineHeight = 24.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.soft(22, 6).clickable(enabled = !busy) { resumePicker.launch("*/*") }.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.UploadFile, null, tint = MC.BlueDeep); Spacer(Modifier.width(8.dp))
            Text(if (busy) "Padh rahi hoon…" else "Resume / details bhejo", color = MC.BlueDeep, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(22.dp))
        Text("Sikhe hue tasks", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        tasks.forEach { (t, s, pkg) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).soft(30, 8).padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t, color = MC.Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(s, color = MC.Blue, fontSize = 14.sp)
                }
                Row(Modifier.clickable {
                    val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                    if (i != null) ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else android.widget.Toast.makeText(ctx, "App install nahi hai", android.widget.Toast.LENGTH_SHORT).show()
                }, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PlayArrow, null, tint = MC.Blue, modifier = Modifier.size(18.dp))
                    Text("Chalao", color = MC.Blue, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).soft(26, 8).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Baat ke baad khud yaad rakhe", color = MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Har baat khatam hone par kaam ki baatein khud save karti hai", color = MC.Sub, fontSize = 15.sp)
            }
            Switch(auto, { auto = it; prefs.edit().putBoolean("auto_memory", it).apply() })
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().soft(26, 8).clickable { showBackup = true }.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CloudUpload, null, tint = MC.Navy); Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Backup & restore", color = MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Apni yaadein aur chats dusre phone pe le jao", color = MC.Sub, fontSize = 15.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = MC.Navy)
        }
        Spacer(Modifier.height(24.dp))
    }
    if (showBackup) AlertDialog(
        onDismissRequest = { showBackup = false },
        title = { Text("Backup & restore") },
        text = { Text("Yaadein dusre phone pe le jane ke liye Backup bhejo, naye phone pe Restore se wapas lo.") },
        confirmButton = { TextButton({
            showBackup = false
            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, PersistentMemory.all().joinToString("\n")) }
            ctx.startActivity(Intent.createChooser(i, "Backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Backup bhejo") } },
        dismissButton = { TextButton({ showBackup = false; restorePicker.launch("text/*") }) { Text("Restore karo") } }
    )
}

@Composable
private fun DrawerContent(onHome: () -> Unit, onArea: (String) -> Unit, onSettings: () -> Unit, onAccessibility: () -> Unit, onPhotos: () -> Unit, onBrowser: () -> Unit, onDialog: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    data class D(val label: String, val icon: ImageVector, val dot: Boolean = false, val action: () -> Unit)
    val home = listOf(D("Home", Icons.Filled.Home) { onHome() }, D("Maya Home", Icons.Filled.Home) { onHome() })
    val work = listOf(
        D("Markets", Icons.Filled.TrendingUp) { onArea("Markets") }, D("Marketing", Icons.Filled.Storefront) { onArea("Marketing") },
        D("Documents", Icons.Filled.Description) { onArea("Documents") }, D("Meri photos", Icons.Filled.PhotoLibrary) { onPhotos() },
        D("Website / Coding", Icons.Filled.Code) { onArea("Website / Coding") }, D("Terminal", Icons.Filled.Terminal) { onArea("Terminal") },
        D("Games with Maya", Icons.Filled.SportsEsports) { onArea("Games") }, D("Browser", Icons.Filled.Language) { onBrowser() },
        D("Accessibility", Icons.Filled.Accessibility) { onAccessibility() })
    val sys = listOf(
        D("Settings", Icons.Filled.Settings) { onSettings() },
        D("Maya ke rules", Icons.Filled.VerifiedUser) { onDialog("Maya ke rules") },
        D("PC ⇄ Phone", Icons.Filled.SwapHoriz) { onDialog("PC ⇄ Phone") })
    val aur = listOf(
        D("Privacy Policy", Icons.Filled.Lock) { onDialog("Privacy Policy") },
        D("About", Icons.Filled.Info) { onDialog("About") },
        D("Upgrade", Icons.Filled.Star) { onDialog("Upgrade") },
        D("Notifications", Icons.Filled.NotificationsNone, dot = true) { onDialog("Notifications") })
    ModalDrawerSheet(drawerContainerColor = MC.LightBg, modifier = Modifier.width(310.dp)) {
        Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                MayaLogo(64); Spacer(Modifier.width(14.dp))
                Column { Text("Maya", color = MC.Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("by The Hunter AI", color = MC.Sub, fontSize = 16.sp) }
            }
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth().height(56.dp).soft(28, 4).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Search, null, tint = MC.Sub); Spacer(Modifier.width(12.dp))
                Box { if (q.isEmpty()) Text("Settings me dhundo", color = MC.Sub, fontSize = 18.sp)
                    BasicTextField(q, { q = it }, singleLine = true, textStyle = TextStyle(color = MC.Navy, fontSize = 18.sp), modifier = Modifier.fillMaxWidth()) }
            }
            fun section(title: String, list: List<D>): @Composable () -> Unit = {
                val f = list.filter { q.isBlank() || it.label.contains(q, true) }
                if (f.isNotEmpty()) {
                    Text(title, color = MC.Sub, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp, start = 6.dp))
                    f.forEachIndexed { idx, d ->
                        val active = title == "HOME" && idx == 0
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).height(64.dp).let {
                            if (active) it.clip(RoundedCornerShape(22.dp)).background(Brush.verticalGradient(listOf(Color(0xFF66B6FF), MC.BlueDeep))) else it.soft(22, 6)
                        }.clickable { d.action() }.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(d.icon, null, tint = if (active) Color.White else MC.BlueDeep); Spacer(Modifier.width(16.dp))
                            Text(d.label, color = if (active) Color.White else MC.Navy, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            if (d.dot) Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFFE67E00)))
                        }
                    }
                }
            }
            section("HOME", home)(); section("KAAM-KAAJ", work)(); section("SYSTEM", sys)(); section("AUR", aur)()
            Spacer(Modifier.height(20.dp))
            Text("$VERSION  ·  The Hunter AI", color = MC.Sub, fontSize = 15.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}


@Composable
private fun MayaDialog(kind: String, prefs: android.content.SharedPreferences, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember {
        mutableStateOf(when (kind) { "Maya ke rules" -> prefs.getString("maya_rules", "").orEmpty(); "Upgrade" -> prefs.getString("license_code", "").orEmpty(); else -> "" })
    }
    val editable = kind == "Maya ke rules" || kind == "Upgrade"
    val body = when (kind) {
        "Maya ke rules" -> "Maya ke liye apne rules likho (jaise: hamesha Hindi me bolo, raat ko call mat karo). Har baat-cheet me Maya inhe follow karegi."
        "PC ⇄ Phone" -> "Phone se PC pe text ya file bhejne ke liye Share dabao aur apna PC / Drive / WhatsApp Web chuno."
        "Privacy Policy" -> "Tumhari Gemini key sirf is phone me save hoti hai aur sirf Google Gemini ko request bhejne me use hoti hai. Chat aur yaadein phone me hi rehti hain. Mic, camera, SMS, contacts jaise permissions sirf tab use hote hain jab tum Maya se kaam karwate ho."
        "About" -> "Maya by The Hunter AI\n$VERSION\nVoice, chat, screen aur phone control wali AI assistant."
        "Upgrade" -> "License code yahan daalo."
        else -> "Abhi koi nayi notification nahi hai. Maya ko WhatsApp / call notifications padhne ke liye Notification access chahiye."
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(kind) },
        text = {
            Column {
                Text(body)
                if (editable) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(), minLines = if (kind == "Upgrade") 1 else 4)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (kind) {
                    "Maya ke rules" -> prefs.edit().putString("maya_rules", text).apply()
                    "Upgrade" -> prefs.edit().putString("license_code", text.trim()).apply()
                    "PC ⇄ Phone" -> ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "") }, "PC / Phone").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Notifications" -> Perms.open(ctx, 2)
                }
                onDismiss()
            }) { Text(when (kind) { "Maya ke rules", "Upgrade" -> "Save"; "PC ⇄ Phone" -> "Share"; "Notifications" -> "Access kholo"; else -> "OK" }) }
        },
        dismissButton = { if (kind == "PC ⇄ Phone" || kind == "Notifications" || editable) TextButton(onDismiss) { Text("Close") } }
    )
}
