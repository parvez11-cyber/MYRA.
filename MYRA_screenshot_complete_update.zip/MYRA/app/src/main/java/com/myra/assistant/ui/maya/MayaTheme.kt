package com.myra.assistant.ui.maya

import androidx.compose.ui.graphics.Color

object MC {
    // Light (home / chat / yaadein)
    val LightBg = Color(0xFFD9E3F5)
    val Card = Color(0xFFF1F5FD)
    val Navy = Color(0xFF1B2250)
    val Sub = Color(0xFF4A5680)
    val Blue = Color(0xFF3B8EEA)
    val BlueDeep = Color(0xFF1E6FD9)
    val Hint = Color(0xFF8E9AC0)
    val Dot = Color(0xFFD62F6E)
    // Dark (onboarding)
    val DarkBg = Color(0xFF0B1120)
    val DarkCard = Color(0xFF182036)
    val DarkBorder = Color(0xFF2A3350)
    val DarkText = Color(0xFFFFFFFF)
    val DarkSub = Color(0xFF9AA4BD)
    val Accent = Color(0xFF4A7BFF)
    val PendingFg = Color(0xFFFF9800)
    val PendingBg = Color(0xFF3A2A22)
    val DoneFg = Color(0xFF3DDC84)
    val DoneBg = Color(0xFF173226)
}
