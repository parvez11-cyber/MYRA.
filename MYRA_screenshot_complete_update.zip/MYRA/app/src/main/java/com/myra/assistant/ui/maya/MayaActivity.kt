package com.myra.assistant.ui.maya

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.utils.Constants

class MayaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        PersistentMemory.init(this)
        val prefs = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        setContent {
            var done by remember { mutableStateOf(prefs.getBoolean("onboarded", false)) }
            if (done) MayaApp() else OnboardingScreen { done = true }
        }
    }
}
