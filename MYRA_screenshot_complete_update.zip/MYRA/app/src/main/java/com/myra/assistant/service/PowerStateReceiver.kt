package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.ArrayDeque
import java.util.Locale

/**
 * Offline announcements for power/battery events.
 *
 * A single process-wide TTS engine and FIFO queue prevent overlapping engines
 * from talking over one another when Android delivers nearby power broadcasts.
 */
class PowerStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("offline_power_voice", true)) return

        val action = intent.action ?: return
        val message = when (action) {
            Intent.ACTION_POWER_CONNECTED -> "Charger connected."
            Intent.ACTION_POWER_DISCONNECTED -> "Charger disconnected."
            Intent.ACTION_BATTERY_LOW -> "Battery is low. Please charge your phone."
            Intent.ACTION_BATTERY_OKAY -> "Battery level is okay again."
            else -> return
        }

        val pending = goAsync()
        main.post {
            // Android can emit duplicate broadcasts close together on some devices.
            val now = System.currentTimeMillis()
            synchronized(lock) {
                if (lastAction == action && now - lastActionAt < DUPLICATE_WINDOW_MS) {
                    pending.finish()
                    return@post
                }
                lastAction = action
                lastActionAt = now
                queue.addLast(Task(message, pending))
                ensureEngine(context.applicationContext)
                speakNext()
            }
        }
    }

    private data class Task(val message: String, val pending: BroadcastReceiver.PendingResult)

    companion object {
        private const val DUPLICATE_WINDOW_MS = 1800L
        private val lock = Any()
        private val main = Handler(Looper.getMainLooper())
        private val queue = ArrayDeque<Task>()
        private var engine: TextToSpeech? = null
        private var engineReady = false
        private var speaking = false
        private var lastAction: String? = null
        private var lastActionAt = 0L

        private fun ensureEngine(context: Context) {
            if (engine != null) return
            engine = TextToSpeech(context) { status ->
                synchronized(lock) {
                    engineReady = status == TextToSpeech.SUCCESS
                    if (engineReady) {
                        engine?.language = Locale.getDefault()
                        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) = main.post { finishCurrent() }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) = main.post { finishCurrent() }
                        })
                        speakNext()
                    } else {
                        while (queue.isNotEmpty()) queue.removeFirst().pending.finish()
                        engine?.shutdown()
                        engine = null
                    }
                }
            }
        }

        private fun speakNext() {
            if (!engineReady || speaking || queue.isEmpty()) return
            val task = queue.first()
            speaking = true
            val result = engine?.speak(
                task.message,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "myra_power_${System.nanoTime()}"
            ) ?: TextToSpeech.ERROR
            if (result == TextToSpeech.ERROR) finishCurrent()
        }

        private fun finishCurrent() {
            synchronized(lock) {
                if (queue.isNotEmpty()) queue.removeFirst().pending.finish()
                speaking = false
                speakNext()
            }
        }
    }
}
