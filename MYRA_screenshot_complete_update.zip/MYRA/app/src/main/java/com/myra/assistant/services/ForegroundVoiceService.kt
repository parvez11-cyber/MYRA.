package com.myra.assistant.services

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.myra.assistant.R
import com.myra.assistant.ai.AIResponseManager
import com.myra.assistant.ai.ConversationMemory
import com.myra.assistant.ai.PersistentMemory
import com.myra.assistant.ai.IntentAnalyzer
import com.myra.assistant.ai.DynamicDecisionEngine
import com.myra.assistant.notification.NotificationReaderService
import com.myra.assistant.ui.maya.MayaActivity
import com.myra.assistant.utils.Constants
import com.myra.assistant.utils.Logger
import com.myra.assistant.utils.RootAccess
import com.myra.assistant.utils.prefs
import com.myra.assistant.voice.AudioFocusManager
import com.myra.assistant.voice.AudioPlayer
import com.myra.assistant.voice.AudioRecorder
import com.myra.assistant.voice.VoiceActivityDetector
import com.myra.assistant.voice.VoiceStateManager
import com.myra.assistant.websocket.GeminiWebSocketClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.ArrayDeque

class ForegroundVoiceService : Service() {

    private val TAG = "VOICE_SVC"
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private val preRoll = ArrayDeque<ByteArray>()
    private val silenceTail = ByteArray(1024)

    private lateinit var audioRecorder: AudioRecorder
    private lateinit var audioPlayer: AudioPlayer
    private lateinit var vad: VoiceActivityDetector
    private lateinit var audioFocus: AudioFocusManager

    private var geminiClient: GeminiWebSocketClient? = null

    @Volatile
    private var micEnabled = false

    companion object {
        var instance: ForegroundVoiceService? = null
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()

        instance = this
        isRunning = true

        PersistentMemory.init(this)

        try {
            androidx.core.app.ServiceCompat.startForeground(
                this,
                Constants.NOTIF_ID_VOICE,
                buildNotification(),
                if (Build.VERSION.SDK_INT >= 30)
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                else 0
            )
        } catch (e: Exception) {
            // Android 14+ blocks mic FGS when started from background / without RECORD_AUDIO
            Logger.e("ForegroundVoiceService", "cannot start foreground", e)
            stopSelf()
            return
        }

        scope.launch {
            RootAccess.request(this@ForegroundVoiceService)
        }

        initComponents()
    }

    private fun initComponents() {

        audioFocus = AudioFocusManager(this)

        audioPlayer = AudioPlayer()

        audioPlayer.onPlaybackStarted = {
            VoiceStateManager.setSpeaking()

            if (micEnabled) {
                audioRecorder.stop()
            }
        }

        audioPlayer.onPlaybackFinished = {
            if (micEnabled) {
                VoiceStateManager.setListening()
                audioRecorder.start()
            } else {
                VoiceStateManager.setIdle()
            }
        }

        vad = VoiceActivityDetector(

            onSpeechStart = {
                VoiceStateManager.setListening()

                preRoll.forEach {
                    geminiClient?.sendAudioChunk(it)
                }

                preRoll.clear()
            },

            onSpeechEnd = {
                repeat(6) {
                    geminiClient?.sendAudioChunk(silenceTail)
                }

                VoiceStateManager.setThinking()
            }
        )

        audioRecorder = AudioRecorder(this) { chunk ->

            if (
                micEnabled &&
                !VoiceStateManager.isAiSpeaking()
            ) {

                if (preRoll.size >= 4) {
                    preRoll.removeFirst()
                }

                preRoll.addLast(chunk.copyOf())

                vad.processChunk(chunk)

                if (vad.isSpeechActive()) {
                    geminiClient?.sendAudioChunk(chunk)
                }
            }
        }

        val apiKey =
            prefs().getString(Constants.KEY_API_KEY, "") ?: ""

        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        }
    }

    private fun connectGemini(apiKey: String) {

        geminiClient?.disconnect()

        geminiClient = GeminiWebSocketClient(

            apiKey = apiKey,

            systemPrompt = buildSystemPrompt(),

            onConnected = {

                if (micEnabled) {

                    VoiceStateManager.setListening()

                    audioRecorder.start()

                } else {

                    VoiceStateManager.setIdle()
                }
            },

            onAudioReceived = { data ->
                audioPlayer.playChunk(data)
            },

            onTextReceived = { text ->

                val clean = AIResponseManager.clean(text)

                if (clean.isNotBlank()) {

                    ConversationMemory.addAssistant(clean)

                    val cmd =
                        AIResponseManager.extractCommand(clean)

                    if (cmd != null) {

                        scope.launch {

                            val intent =
                                IntentAnalyzer.analyze(cmd)

                            val result =
                                DynamicDecisionEngine.execute(
                                    this@ForegroundVoiceService,
                                    intent
                                )

                            sendBroadcast(
                                Intent("MYRA_COMMAND_RESULT")
                                    .putExtra("text", result)
                            )
                        }
                    }

                    sendBroadcast(
                        Intent("MYRA_RESPONSE")
                            .putExtra("text", clean)
                    )
                }
            },

            onTurnComplete = {

                if (
                    micEnabled &&
                    !audioPlayer.isPlaying()
                ) {

                    if (!audioRecorder.isActive()) {
                        audioRecorder.start()
                    }

                    VoiceStateManager.setListening()
                }
            },

            onError = { msg ->

                Logger.e(
                    TAG,
                    "Gemini error: $msg"
                )

                VoiceStateManager.setError(
                    "Reconnecting…"
                )

                scope.launch {

                    delay(1800)

                    if (
                        geminiClient?.isConnected() != true
                    ) {
                        geminiClient?.connect()
                    }
                }
            }
        )

        geminiClient?.connect()
    }

    fun setMicEnabled(enabled: Boolean) {

        micEnabled = enabled

        prefs()
            .edit()
            .putBoolean(
                "mic_enabled",
                enabled
            )
            .apply()

        if (enabled) {

            VoiceStateManager.setListening()

            if (
                geminiClient?.isConnected() == true
            ) {

                audioRecorder.start()

            } else {

                reconnectGemini()
            }

        } else {

            audioRecorder.stop()

            vad.reset()

            preRoll.clear()

            VoiceStateManager.setIdle()
        }

        sendBroadcast(
            Intent("MYRA_MIC_STATE")
                .putExtra(
                    "enabled",
                    enabled
                )
        )
    }

    fun isMicEnabled(): Boolean {
        return micEnabled
    }

    /*
     * Image message
     *
     * GeminiWebSocketClient-এর মধ্যে sendImageMessage()
     * function না থাকায় এখানে image-এর caption/text পাঠানো হচ্ছে।
     *
     * এতে build error হবে না।
     */
    fun sendImageToGemini(
        text: String,
        imageBytes: ByteArray,
        mimeType: String
    ) {

        if (
            geminiClient?.isConnected() != true
        ) {

            reconnectGemini()
            return
        }

        val message =
            if (text.isBlank()) {
                "[Image attached]"
            } else {
                text
            }

        ConversationMemory.addUser(message)

        VoiceStateManager.setThinking()

        geminiClient?.sendTextMessage(message)
    }

    fun sendTextToGemini(text: String) {

        if (
            geminiClient?.isConnected() != true
        ) {

            reconnectGemini()
            return
        }

        ConversationMemory.addUser(text)

        VoiceStateManager.setThinking()

        geminiClient?.sendTextMessage(text)
    }

    fun replyToLatestNotification(
        message: String
    ): Boolean {

        return NotificationReaderService
            .instance
            ?.replyToLatest(message) == true
    }

    fun replyToNotification(
        target: String?,
        message: String
    ): Boolean {

        return NotificationReaderService
            .instance
            ?.replyTo(
                target,
                message
            ) == true
    }

    fun reconnectGemini() {

        val apiKey =
            prefs().getString(
                Constants.KEY_API_KEY,
                ""
            ) ?: ""

        if (apiKey.isNotEmpty()) {
            connectGemini(apiKey)
        }
    }

    private fun buildSystemPrompt(): String {

        val userName =
            prefs().getString(
                Constants.KEY_USER_NAME,
                "Boss"
            ) ?: "Boss"

        val personality =
            prefs().getString(
                Constants.KEY_PERSONALITY,
                "friendly"
            ) ?: "friendly"

        return """
YOU ARE MYRA - My Yours Responsive Assistant.
User's name is $userName.
Personality: $personality.
Custom memory saved on this device:
${PersistentMemory.contextForAI()}

STRICT RULES:

- Never explain or think aloud.

- For device actions return ONLY one command:

OPEN_APP <name>
CALL <name>
WHATSAPP_CALL <name>
WHATSAPP_MSG <name> <message>
YOUTUBE_PLAY <query>
SPOTIFY_PLAY <query>
FLASHLIGHT_ON
FLASHLIGHT_OFF
VOLUME_UP
VOLUME_DOWN
HOME
BACK
RECENTS
NOTIFICATIONS
SMS <name> <message>
REPLY_NOTIFICATION <message>
REPLY_NOTIFICATION_TO <app-or-name> <message>

- For conversation:
reply short, natural, and primarily in Bangla (বাংলা).

- Understand Bangla, Banglish, and English commands.

- Address user as $userName.

- Be warm, concise, witty, and human-like.

- Do not claim to be offline unless the service is actually stopped.

        """.trimIndent()
    }

    private fun buildNotification(): Notification {

        createChannel()

        val pi =
            PendingIntent.getActivity(
                this,
                0,
                Intent(
                    this,
                    MayaActivity::class.java
                ),
                PendingIntent.FLAG_UPDATE_CURRENT or
                        PendingIntent.FLAG_IMMUTABLE
            )

        return NotificationCompat.Builder(
            this,
            Constants.NOTIF_CHANNEL_VOICE
        )
            .setContentTitle(
                "MYRA AI • Online"
            )
            .setContentText(
                "Maya is ready."
            )
            .setSmallIcon(
                R.drawable.ic_myra_notif
            )
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(
                NotificationCompat.PRIORITY_LOW
            )
            .build()
    }

    private fun createChannel() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val ch =
                NotificationChannel(
                    Constants.NOTIF_CHANNEL_VOICE,
                    "MYRA Voice Service",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    setShowBadge(false)
                }

            getSystemService(
                NotificationManager::class.java
            ).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            Constants.ACTION_START_LISTENING ->
                setMicEnabled(true)

            Constants.ACTION_STOP_LISTENING ->
                setMicEnabled(false)
        }

        return START_STICKY
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {
        return null
    }

    override fun onDestroy() {

        isRunning = false

        instance = null

        micEnabled = false

        if (::audioRecorder.isInitialized) {
            audioRecorder.stop()
        }

        if (::audioPlayer.isInitialized) {
            audioPlayer.release()
        }

        geminiClient?.disconnect()

        job.cancel()

        super.onDestroy()
    }
}
