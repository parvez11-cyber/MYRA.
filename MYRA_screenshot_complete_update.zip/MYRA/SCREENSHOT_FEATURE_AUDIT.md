# MYRA screenshot-to-project checklist

The primary launcher remains `MayaActivity` -> `MayaApp`; the legacy `MainActivity`
and its supporting automation/voice modules are retained rather than removed.

## Screenshot areas represented in the project
- Three-stage setup: Gemini API key, runtime permissions, and background/system permissions
  (`ui/maya/OnboardingScreen.kt`, `Perms.kt`).
- Home, Scanner, Yaaadein, Chat and bottom navigation
  (`ui/maya/MayaApp.kt`).
- Side drawer sections and navigation entries
  (`DrawerContent` in `MayaApp.kt`).
- Floating orb / microphone state indicator
  (`MyraOverlayService`, `overlay_orb.xml`, `ForegroundVoiceService`).
- Offline charging and battery announcements
  (`PowerStateReceiver.kt`).
- Voice, memory, notification, accessibility, screen vision, call and automation modules
  are retained in their existing packages.

## Reliability change in this update
`PowerStateReceiver` now serializes offline TTS announcements through one shared engine
and a FIFO queue, and suppresses an identical power broadcast repeated within 1.8 seconds.
This reduces overlapping/duplicate speech for charger and battery events.

## Items that still require device-side verification
- Exact pixel matching depends on the target phone's density, Android version and font rendering.
- Overlay, microphone, notification-listener, accessibility, call and battery-exemption
  features require the corresponding user-granted Android settings.
- Background microphone restrictions and OEM battery managers vary by device.
- The repository does not contain a standalone `maya_character` drawable; `MayaApp`
  currently has a vector placeholder fallback. Add the licensed/original character artwork
  as `app/src/main/res/drawable/maya_character.png` to match the home reference exactly.
- Build and runtime QA must be completed on a machine with Android SDK API 36 and JDK 17+.
